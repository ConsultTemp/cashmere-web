export const studios = [
  { id: "a9xgk7yq34mnp0z2vwsdl5btc", name: "Studio 1" },
  { id: "fj2m48xyn0vrkzqwtlcsd96bp", name: "Studio 2" },
  { id: "z7wqktx3y0m24vn9slcbdg5rp", name: "Studio 3" },
  { id: "m3v9xtkq2wsn74yl0cbdg5prz", name: "Studio 4" }
];

export const services = [
  { "id": "838jf1d16rf5q25ddlxszgtxo6", "name": "Beat in session" },
  { "id": "bre5y3oupkoy1p5n6adf9w5kyr", "name": "4h + 2 Mix&Master", duration: 4 },
  { "id": "ivljinhh3cj10wem26i7mup2kr", "name": "2h + 1 Mix&Master", duration: 2 },
  { "id": "nqz3v7xk2y0mlw4tscbdf9grp", "name": "Produzione" },
  { "id": "p4xv7qk2m90zylwtscbdg3nfr", "name": "Registrazione" },
  { "id": "wtscbdf9xv7qkz0m2y4nlgr3p", "name": "Affitto sala" },
  { "id": "x8o0secmg2jie6o3jqiviaz7kx", "name": "2h + 1 Mix&Master + 1 beat", duration: 2 },
  { "id": "y0m2xv7qkz4nlwt3cbdf9srpg", "name": "Mix&Master" }
]
